def cha(a):
 a = 2
 print a
x=1;
cha(x);
print x
