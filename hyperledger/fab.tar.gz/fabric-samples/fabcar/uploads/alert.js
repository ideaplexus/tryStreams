#!/Library/Frameworks/Python.framework/Versions/2.7/bin/python
import python module elan as elan
elan.elan('python')