var fs = require('fs');
var path = require('path');
var basePath = __dirname + '/uploads/';
var crypto = require('crypto');
var hashvalue;
var filevalue;
module.exports = {

    uplodfile: function(err,filename,callback) {
       console.log("inside file",filename);
       var fullpath = basePath+filename;
      function checksum (str, algorithm, encoding) {
      return crypto
          .createHash(algorithm || 'md5')
          .update(str, 'utf8')
          .digest(encoding || 'hex')
  }
        fs.readFile(fullpath, function (err, data) {      
          hashvalue= checksum(data, 'sha256'); 
          callback(null,hashvalue);
        });
        

    },

    filelength:function(err,callback){
       fs.readdir(basePath, (err, files) => {
          filevalue= files.length; 
           callback(null,filevalue);
        });
    }


}    

    


    