var express = require("express");
var app     = express();
var path    = require("path");
var bodyParser = require('body-parser');
var multer = require('multer');
//var reguser = require('./registerUser');
var signin = require('./signIn');
var login = require('./login');
var invoke = require('./invoke');
var query = require('./query');
var fs = require('fs');
var fileupload = require('./FileUpload');
var multerS3 = require('multer-s3');
var  aws = require('aws-sdk');
var filename = '';
var pusharr = [];
aws.config.update({
    secretAccessKey: 'pNvexcZ4e5eo2DTDug09gzKUkkRFzChEuvIrJbEE',
    accessKeyId: 'AKIAI3GVNV4IGT6JAFMQ'
});
var params = {Bucket:'vahaiblock', Key: '', Expires: 20000000};
var s3 = new aws.S3();
s3.listBuckets(function(err, data) {
   if (err) {
      console.log("Error", err);
   } else {
      console.log("Bucket List", data.Buckets);
   }
});
// Create our bucket if it doesn't exist
var glocreate = {};
var gloquery = {}; 
app.use(bodyParser.urlencoded({ extended: false }))
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/index.html'));
});
app.get('/login',function(req,res){
  res.sendFile(path.join(__dirname+'/login.html'));
});
app.get('/listobjects',function(req,res){
  pusharr = [];
  var rc = req.headers.cookie;
  var splitrc = rc.split(';');
  console.log(splitrc);
  var spliname = splitrc[0].split('=');
  console.log(spliname);
  gloquery.username =spliname[1];
  gloquery.fnname = 'queryAllFile';
  query.queryfile(gloquery,function(err,data){
    if (err) return console.error(err);
   var array = JSON.parse(data);
   console.log(array);
   for(i=0;i<array.length;i++){
            console.log(array[i].Record);
            if(spliname[1] == array[i].Record.uname){
              pusharr.push(array[i].Record);
            }
            
    }
   res.send(pusharr);
  });
});

app.get('/upload',function(req,res){

  res.sendFile(path.join(__dirname+'/upload.html'));
});

app.post('/siginin',function(request,response){

signin.fab(request,response);

});

var storage = multer.diskStorage({
	destination: function(req, file, callback) {
		callback(null, './uploads')
	},
	filename: function(req, file, callback) {
		callback(null, file.originalname)
	}
});
var storage1 = multerS3({
        s3: s3,
        bucket: 'vahaiblock',
        key: function (req, file, cb) {
            cb(null, file.originalname); //use Date.now() for unique file keys
        }
    });
app.post('/login',function(request,response){

login.fab(request,response);

});

app.post('/uploadfile',function(req,res){
var upload = multer({
		storage: storage1
	}).single('uploadFile')
	upload(req, res, function(err) {
		s3.getSignedUrl('getObject', params, function (err, url) {
	}); 
    });
    
    
    var upload1 = multer({
		storage: storage
	}).single('uploadFile')
	upload1(req, res, function(err) {
    var rc = req.headers.cookie;
    var splitrc = rc.split(';');
    console.log(splitrc);
  var spliname = splitrc[0].split('=');
    console.log(spliname);
   
		filehash = fileupload.uplodfile(err,req.file.originalname,function(err,data){if (err) return console.error(err);
   console.log(data);
   glocreate.hash = data;
   glocreate.linkname = "https://s3.ap-south-1.amazonaws.com/vahaiblock/"+req.file.originalname;
   glocreate.filename = req.file.originalname;
   glocreate.fnname = 'createFile';
   glocreate.username = spliname[1];
   fileupload.filelength(err,function(err,data){
  if (err) return console.error(err);
   console.log(data);
   glocreate.filelength = data;
   console.log(glocreate);
   invoke.invokefun(glocreate);
 });

   
 });
    //

       res.end('File is uploaded');
    });
		
});
app.listen(3000);

console.log("Running at Port 3000");
